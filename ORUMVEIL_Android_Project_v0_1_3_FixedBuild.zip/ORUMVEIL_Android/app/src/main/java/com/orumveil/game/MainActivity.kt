package com.orumveil.game

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.graphics.BitmapFactory
import android.graphics.Color
import android.content.pm.ActivityInfo
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private lateinit var game: WebView
    private lateinit var root: FrameLayout
    private lateinit var splash: ImageView

    @Suppress("DEPRECATION")
    private fun applyImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        applyImmersiveMode()

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        game = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mediaPlaybackRequiresUserGesture = true
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    visibility = View.VISIBLE
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (::splash.isInitialized && splash.parent != null) root.removeView(splash)
                    }, 700)
                }
            }
            webChromeClient = WebChromeClient()
            visibility = View.INVISIBLE
        }
        root.addView(game, FrameLayout.LayoutParams(-1, -1))

        splash = ImageView(this).apply {
            setImageBitmap(BitmapFactory.decodeStream(assets.open("splash.png")))
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "ORUMVEIL — загрузка города"
        }
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        game.loadUrl("file:///android_asset/index.html")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::game.isInitialized && game.canGoBack()) game.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::game.isInitialized) {
            game.stopLoading()
            game.loadUrl("about:blank")
            game.removeAllViews()
            game.destroy()
        }
        super.onDestroy()
    }
}
